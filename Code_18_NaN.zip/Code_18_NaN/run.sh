#!/bin/bash
# run crawler.py
python code/crawler.py